This directory contains projects using TensorFlow Model Garden Modeling
libraries.
