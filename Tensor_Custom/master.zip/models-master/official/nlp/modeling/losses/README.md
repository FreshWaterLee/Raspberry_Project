# Losses

Losses contains common loss computation used in NLP tasks.

* `weighted_sparse_categorical_crossentropy_loss` computes per-batch sparse
categorical crossentropy loss.
